package prj5;

import list.AList;

/**
 * Glyph Generator Class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.07
 */
public class GlyphGenerator
{

    private SongList<Song> songs;
    private AList<Glyph>   glyphsByMajor;
    private AList<Glyph>   glyphsByHobby;
    private AList<Glyph>   glyphsByState;


    public GlyphGenerator(SongList<Song> songList)
    {
        songs = songList;
        glyphsByMajor = new AList<Glyph>();
        glyphsByHobby = new AList<Glyph>();
        glyphsByState = new AList<Glyph>();
    }


    public SongList<Song> getSongs()
    {
        return songs;

    }


    public AList<Glyph> getGlyphsByMajor()
    {
        return glyphsByMajor;
    }


    public AList<Glyph> getGlyphsByHobby()
    {
        return glyphsByHobby;
    }


    public AList<Glyph> getGlyphsByState()
    {
        return glyphsByState;
    }


    public AList<Glyph> createGlyphsByMajor()
    {
        for (int i = 0; i < songs.size(); i++)
        {
            Song current = songs.get(i);

            int likePercent = current.majorsPercentages[1];
            int heardPercent = current.majorsPercentages[0];
            Glyph currentGlyph = new Glyph();
            currentGlyph.createBar("top", likePercent, heardPercent);

            int likePercent2 = current.majorsPercentages[3];
            int heardPercent2 = current.majorsPercentages[2];
            currentGlyph.createBar("midTop", likePercent2, heardPercent2);

            int likePercent3 = current.majorsPercentages[5];
            int heardPercent3 = current.majorsPercentages[4];
            currentGlyph.createBar("midBottom", likePercent3, heardPercent3);

            int likePercent4 = current.majorsPercentages[7];
            int heardPercent4 = current.majorsPercentages[6];
            currentGlyph.createBar("bottom", likePercent4, heardPercent4);

            glyphsByMajor.add(currentGlyph);
        }
        return glyphsByMajor;
    }


    public AList<Glyph> createGlyphsByHobby()
    {
        for (int i = 0; i < songs.size(); i++)
        {
            Song current = songs.get(i);

            int likePercent = current.hobbiesPercentages[1];
            int heardPercent = current.hobbiesPercentages[0];
            Glyph currentGlyph = new Glyph();
            currentGlyph.createBar("top", likePercent, heardPercent);

            int likePercent2 = current.hobbiesPercentages[3];
            int heardPercent2 = current.hobbiesPercentages[2];
            currentGlyph.createBar("midTop", likePercent2, heardPercent2);

            int likePercent3 = current.hobbiesPercentages[5];
            int heardPercent3 = current.hobbiesPercentages[4];
            currentGlyph.createBar("midBottom", likePercent3, heardPercent3);

            int likePercent4 = current.hobbiesPercentages[7];
            int heardPercent4 = current.hobbiesPercentages[6];
            currentGlyph.createBar("bottom", likePercent4, heardPercent4);

            glyphsByHobby.add(currentGlyph);
        }
        return glyphsByHobby;
    }


    public AList<Glyph> createGlyphsByState()
    {
        for (int i = 0; i < songs.size(); i++)
        {
            Song current = songs.get(i);

            int likePercent = current.statesPercentages[1];
            int heardPercent = current.statesPercentages[0];
            Glyph currentGlyph = new Glyph();
            currentGlyph.createBar("top", likePercent, heardPercent);

            int likePercent2 = current.statesPercentages[3];
            int heardPercent2 = current.statesPercentages[2];
            currentGlyph.createBar("midTop", likePercent2, heardPercent2);

            int likePercent3 = current.statesPercentages[5];
            int heardPercent3 = current.statesPercentages[4];
            currentGlyph.createBar("midBottom", likePercent3, heardPercent3);

            int likePercent4 = current.statesPercentages[7];
            int heardPercent4 = current.statesPercentages[6];
            currentGlyph.createBar("bottom", likePercent4, heardPercent4);

            glyphsByState.add(currentGlyph);
        }
        return glyphsByState;
    }
}
