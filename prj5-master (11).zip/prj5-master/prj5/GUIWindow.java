package prj5;

import java.awt.Color;

import CS2114.Button;
import CS2114.Shape;
import CS2114.TextShape;
import CS2114.Window;
import CS2114.WindowSide;

/**
 * GUI Window class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.11
 *
 */
public class GUIWindow {

    private GlyphGenerator generator;
    private SongList<Song> songs;
    private Window window;

    private Shape legend;
    private TextShape legendTitle;
    private TextShape option1;
    private TextShape option2;
    private TextShape option3;
    private TextShape option4;
    private TextShape songTitle;
    private TextShape heardSide;
    private TextShape likedSide;
    private Shape seperator;

    private Button next;
    private Button previous;
    private Button hobby;
    private Button major;
    private Button state;
    private Button title;
    private Button artist;
    private Button genre;
    private Button date;
    private Button quit;

    /**
     * Constructor that initializes all the field variables
     */
    public GUIWindow() {
        songs = new SongList<Song>();
        generator = new GlyphGenerator(songs);
        window = new Window();
        window.setSize(1000, 1000);

        final int WIDTH = 120;
        final int HEIGHT = 210;
        final int GAP = 155;
        int x = window.getGraphPanelWidth() - WIDTH - 20;
        int y = window.getGraphPanelHeight() - HEIGHT - 60;
        legend = new Shape(x, y, WIDTH, HEIGHT);
        legend.setBackgroundColor(Color.WHITE);
        legend.setForegroundColor(Color.BLACK);
        seperator = new Shape(897, y + GAP, 3, 50);
        seperator.setBackgroundColor(Color.BLACK);
        seperator.setForegroundColor(Color.BLACK);
        window.addShape(seperator);
        legendTitle = new TextShape(x + 3, (y + 2), "Hobby Legend");
        legendTitle.setBackgroundColor(Color.WHITE);
        window.addShape(legendTitle);
        option1 = new TextShape(x + 1, y + 20, "read");
        option1.setForegroundColor(Color.PINK);
        option1.setBackgroundColor(Color.WHITE);
        window.addShape(option1);
        option2 = new TextShape(x + 1, y + 35, "art");
        option2.setForegroundColor(Color.BLUE);
        option2.setBackgroundColor(Color.WHITE);
        window.addShape(option2);
        option3 = new TextShape(x + 1, y + 50, "sports");
        option3.setForegroundColor(Color.YELLOW);
        option3.setBackgroundColor(Color.WHITE);
        window.addShape(option3);
        option4 = new TextShape(x + 1, y + 65, "music");
        option4.setForegroundColor(Color.GREEN);
        option4.setBackgroundColor(Color.WHITE);
        window.addShape(option4);
        songTitle = new TextShape(x + 3, y + 100, "Song Title");
        songTitle.setBackgroundColor(Color.WHITE);
        window.addShape(songTitle);
        heardSide = new TextShape(850, y + GAP, "Heard");
        heardSide.setBackgroundColor(Color.WHITE);
        window.addShape(heardSide);
        likedSide = new TextShape(905, y + GAP, "Likes");
        likedSide.setBackgroundColor(Color.WHITE);
        window.addShape(likedSide);
        window.addShape(legend);

        previous = new Button("Previous");
        window.addButton(previous, WindowSide.NORTH);
        previous.onClick(this, "clickedPrevious");

        artist = new Button("Sort by Artist Name");
        window.addButton(artist, WindowSide.NORTH);
        artist.onClick(this, "clickedArtist");

        title = new Button("Sort by Song Title");
        window.addButton(title, WindowSide.NORTH);
        title.onClick(this, "clickedTitle");

        date = new Button("Sort by Release Year");
        window.addButton(date, WindowSide.NORTH);
        date.onClick(this, "clickedDate");

        genre = new Button("Sort by Genre");
        window.addButton(genre, WindowSide.NORTH);
        genre.onClick(this, "clickedGenre");

        next = new Button("Next");
        window.addButton(next, WindowSide.NORTH);
        next.onClick(this, "clickedNext");

        hobby = new Button("Represent Hobby");
        window.addButton(hobby, WindowSide.SOUTH);
        hobby.onClick(this, "clickedHobby");

        major = new Button("Represent Major");
        window.addButton(major, WindowSide.SOUTH);
        major.onClick(this, "clickedMajor");

        state = new Button("Represent Region");
        window.addButton(state, WindowSide.SOUTH);
        state.onClick(this, "clickedState");

        quit = new Button("Quit");
        window.addButton(quit, WindowSide.SOUTH);
        quit.onClick(this, "clickedQuit");

        Glyph glyph = new Glyph();
        glyph.createBar("bottom", 10, 10);
        glyph.createBar("midBottom", 5, 4);
        glyph.createBar("midTop", 10, 10);
        glyph.createBar("top", 4, 5);
        window.addShape(glyph);

    }

    /**
     * Gets the window field
     * 
     * @return window the window field
     */
    public Window getWindow() {
        return window;

    }

    /**
     * Shows the next set of glyphs on the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedNext(Button source) {

    }

    /**
     * Shows the previous set of glyphs on the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedPrevious(Button source) {

    }

    /**
     * Closes the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedQuit(Button source) {
        System.exit(0);
    }

    /**
     * Represents the glyphs by hobby, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedHobby(Button source) {
        this.updateLegendText(EnumRepresent.HOBBY);

    }

    /**
     * Represents the glyphs by major, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedMajor(Button source) {
        this.updateLegendText(EnumRepresent.MAJOR);
    }

    /**
     * Represents the glyphs by state, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedState(Button source) {
        this.updateLegendText(EnumRepresent.STATE);
    }

    /**
     * Displays the songs sorted by title
     * 
     * @param source
     *            the button clicked
     */
    public void clickedTitle(Button source) {

    }

    /**
     * Displays the songs sorted by artist
     * 
     * @param source
     *            the button clicked
     */
    public void clickedArtist(Button source) {

    }

    /**
     * Displays the songs sorted by genre
     * 
     * @param source
     *            the button clicked
     */
    public void clickedGenre(Button source) {

    }

    /**
     * Displays the songs sorted by date
     * 
     * @param source
     *            the button clicked
     */
    public void clickedDate(Button source) {

    }

    /**
     * Updates the textShapes in the legend
     * 
     * @param represent
     *            the enumerator passed in
     */
    public void updateLegendText(EnumRepresent represent) {
        if (represent == EnumRepresent.HOBBY) {
            legendTitle.setText("Hobby Legend");
            option1.setText("read");
            option2.setText("art");
            option3.setText("sports");
            option4.setText("music");
        }
        else if (represent == EnumRepresent.MAJOR) {
            legendTitle.setText("Major Legend");
            option1.setText("Computer Science");
            option2.setText("Other Engineering");
            option3.setText("Math or CMDA");
            option4.setText("Other");
        }
        else if (represent == EnumRepresent.STATE) {
            legendTitle.setText("Region Legend");
            option1.setText("Northeast");
            option2.setText("Southeast");
            option3.setText("Rest of the US");
            option4.setText("Outside of the US");
        }

    }

}
