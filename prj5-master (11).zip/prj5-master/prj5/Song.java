package prj5;

/**
 * Song Class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.07
 */
public class Song
{

    private String           title;
    private String           artist;
    private String           genre;
    private String           date;
    private int[]            majors;
    private int[]            hobbies;
    private int[]            states;
    public int[]             majorsPercentages;
    public int[]             hobbiesPercentages;
    public int[]             statesPercentages;
    public int[]             totalStudents;

    private int              likePercentage;
    private int              heardPercentage;

    private static final int CAPACITY         = 8;
    private static final int READ_INDEX       = 0;
    private static final int ART_INDEX        = 2;
    private static final int SPORT_INDEX      = 4;
    private static final int MUSIC_INDEX      = 6;

    private static final int CS_INDEX         = 0;
    private static final int ENGE_INDEX       = 2;
    private static final int MATH_INDEX       = 4;
    private static final int OTHER_INDEX      = 6;

    private static final int NORTH_EAST_INDEX = 0;
    private static final int SOUTH_EAST_INDEX = 2;
    private static final int REST_US_INDEX    = 4;
    private static final int OUTSIDE_US_INDEX = 6;


    public Song(String name, String singer, String type, String year)
    {
        title = name;
        artist = singer;
        genre = type;
        date = year;

        majors = new int[CAPACITY];
        hobbies = new int[CAPACITY];
        states = new int[CAPACITY];

        totalStudents = new int[12];

        majorsPercentages = new int[CAPACITY];
        hobbiesPercentages = new int[CAPACITY];
        statesPercentages = new int[CAPACITY];

    }


    public String getTitle()
    {
        return title;

    }


    public String getArtist()
    {
        return artist;
    }


    public String getGenre()
    {
        return genre;
    }


    public String getDate()
    {
        return date;
    }


    public void updateTotalStudents(String type)
    {
        if (type.equals("Computer Science"))
        {
            totalStudents[0] += 1;
        }
        if (type.equals("Other Engineering"))
        {
            totalStudents[1] += 1;
        }
        if (type.equals("Math or CMDA"))
        {
            totalStudents[2] += 1;
        }
        if (type.equals("Other"))
        {
            totalStudents[3] += 1;
        }
        if (type.equals("reading"))
        {
            totalStudents[4] += 1;
        }
        if (type.equals("art"))
        {
            totalStudents[5] += 1;
        }
        if (type.equals("sports"))
        {
            totalStudents[6] += 1;
        }
        if (type.equals("music"))
        {
            totalStudents[7] += 1;
        }
        if (type.equals("Northeast"))
        {
            totalStudents[8] += 1;
        }
        if (type.equals("Southeast"))
        {
            totalStudents[9] += 1;
        }
        if (type.equals("United States (other than Southeast or Northwest)"))
        {
            totalStudents[10] += 1;
        }
        if (type.equals("Outside of United States"))
        {
            totalStudents[11] += 1;
        }
    }


    public void updateHeardMajors(String type)
    {
        if (type.equals("Computer Science"))
        {
            majors[CS_INDEX] += 1;
        }
        if (type.equals("Other Engineering"))
        {
            majors[ENGE_INDEX] += 1;
        }
        if (type.equals("Math or CMDA"))
        {
            majors[MATH_INDEX] += 1;
        }
        if (type.equals("Other"))
        {
            majors[OTHER_INDEX] += 1;
        }

    }


    public void updateLikeMajors(String type)
    {
        if (type.equals("Computer Science"))
        {
            majors[CS_INDEX + 1] += 1;
        }
        if (type.equals("Other Engineering"))
        {
            majors[ENGE_INDEX + 1] += 1;
        }
        if (type.equals("Math or CMDA"))
        {
            majors[MATH_INDEX + 1] += 1;
        }
        if (type.equals("Other"))
        {
            majors[OTHER_INDEX + 1] += 1;
        }

    }


    public void updateHeardHobbies(String type)
    {
        if (type.equals("reading"))
        {
            hobbies[READ_INDEX] += 1;
        }
        if (type.equals("art"))
        {
            hobbies[ART_INDEX] += 1;
        }
        if (type.equals("sports"))
        {
            hobbies[SPORT_INDEX] += 1;
        }
        if (type.equals("music"))
        {
            hobbies[MUSIC_INDEX] += 1;
        }

    }


    public void updateLikeHobbies(String type)
    {
        if (type.equals("reading"))
        {
            hobbies[READ_INDEX + 1] += 1;
        }
        if (type.equals("art"))
        {
            hobbies[ART_INDEX + 1] += 1;
        }
        if (type.equals("sports"))
        {
            hobbies[SPORT_INDEX + 1] += 1;
        }
        if (type.equals("music"))
        {
            hobbies[MUSIC_INDEX + 1] += 1;
        }

    }


    public void updateHeardStates(String type)
    {
        if (type.equals("Northeast"))
        {
            states[NORTH_EAST_INDEX] += 1;
        }
        if (type.equals("Southeast"))
        {
            states[SOUTH_EAST_INDEX] += 1;
        }
        if (type.equals("United States (other than Southeast or Northwest)"))
        {
            states[REST_US_INDEX] += 1;
        }
        if (type.equals("Outside of United States"))
        {
            states[OUTSIDE_US_INDEX] += 1;
        }

    }


    public void updateLikeStates(String type)
    {
        if (type.equals("Northeast"))
        {
            states[NORTH_EAST_INDEX + 1] += 1;
        }
        if (type.equals("Southeast"))
        {
            states[SOUTH_EAST_INDEX + 1] += 1;
        }
        if (type.equals("United States (other than Southeast or Northwest)"))
        {
            states[REST_US_INDEX + 1] += 1;
        }
        if (type.equals("Outside of United States"))
        {
            states[OUTSIDE_US_INDEX + 1] += 1;
        }

    }


    public int getLike(String type)
    {
        if (type.equals("Computer Science"))
        {
            return majors[CS_INDEX + 1];
        }
        if (type.equals("Other Engineering"))
        {
            return majors[ENGE_INDEX + 1];
        }
        if (type.equals("Math or CMDA"))
        {
            return majors[MATH_INDEX + 1];
        }
        if (type.equals("Other"))
        {
            return majors[OTHER_INDEX + 1];
        }
        if (type.equals("reading"))
        {
            return hobbies[READ_INDEX + 1];
        }
        if (type.equals("art"))
        {
            return hobbies[ART_INDEX + 1];
        }
        if (type.equals("sports"))
        {
            return hobbies[SPORT_INDEX + 1];
        }
        if (type.equals("music"))
        {
            return hobbies[MUSIC_INDEX + 1];
        }
        if (type.equals("Northeast"))
        {
            return states[NORTH_EAST_INDEX + 1];
        }
        if (type.equals("Southest"))
        {
            return states[SOUTH_EAST_INDEX + 1];
        }
        if (type.equals("United States (other than Southeast or Northwest)"))
        {
            return states[REST_US_INDEX + 1];
        }
        if (type.equals("Outside of United States"))
        {
            return states[OUTSIDE_US_INDEX + 1];
        }
        return 0;
    }


    public int getHeard(String type)
    {
        if (type.equals("Computer Science"))
        {
            return majors[CS_INDEX];
        }
        if (type.equals("Other Engineering"))
        {
            return majors[ENGE_INDEX];
        }
        if (type.equals("Math or CMDA"))
        {
            return majors[MATH_INDEX];
        }
        if (type.equals("Other"))
        {
            return majors[OTHER_INDEX];
        }
        if (type.equals("reading"))
        {
            return hobbies[READ_INDEX];
        }
        if (type.equals("art"))
        {
            return hobbies[ART_INDEX];
        }
        if (type.equals("sports"))
        {
            return hobbies[SPORT_INDEX];
        }
        if (type.equals("music"))
        {
            return hobbies[MUSIC_INDEX];
        }
        if (type.equals("Northeast"))
        {
            return states[NORTH_EAST_INDEX];
        }
        if (type.equals("Southest"))
        {
            return states[SOUTH_EAST_INDEX];
        }
        if (type.equals("United States (other than Southeast or Northwest)"))
        {
            return states[REST_US_INDEX];
        }
        if (type.equals("Outside of United States"))
        {
            return states[OUTSIDE_US_INDEX];
        }
        return 0;
    }


    public int calculateLikePercentage(int like, int total)
    {
        if (total == 0)
        {
            likePercentage = 0;
            return likePercentage;
        }
        else
        {
            likePercentage = (int)(((double)like / (double)total) * 100);
        }
        return likePercentage;

    }


    public void updateMajorsHeardPercentages()
    {
        int csLike = this.calculateLikePercentage(this.getHeard(
            "Computer Science"), totalStudents[0]);
        majorsPercentages[CS_INDEX] = csLike;
        int engeLike = this.calculateLikePercentage(this.getHeard(
            "Other Engineering"), totalStudents[1]);
        majorsPercentages[ENGE_INDEX] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getHeard(
            "Math or CMDA"), totalStudents[2]);
        majorsPercentages[MATH_INDEX] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getHeard("Other"),
            totalStudents[3]);
        majorsPercentages[OTHER_INDEX] = otherLike;
    }


    public void updateMajorsLikePercentages()
    {
        int csLike = this.calculateLikePercentage(this.getLike(
            "Computer Science"), totalStudents[0]);
        majorsPercentages[CS_INDEX + 1] = csLike;
        int engeLike = this.calculateLikePercentage(this.getLike(
            "Other Engineering"), totalStudents[1]);
        majorsPercentages[ENGE_INDEX + 1] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getLike(
            "Math or CMDA"), totalStudents[2]);
        majorsPercentages[MATH_INDEX + 1] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getLike("Other"),
            totalStudents[3]);
        majorsPercentages[OTHER_INDEX + 1] = otherLike;
    }


    public void updateHobbiesHeardPercentages()
    {
        int csLike = this.calculateLikePercentage(this.getHeard("reading"),
            totalStudents[4]);
        hobbiesPercentages[READ_INDEX] = csLike;
        int engeLike = this.calculateLikePercentage(this.getHeard("art"),
            totalStudents[5]);
        hobbiesPercentages[ART_INDEX] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getHeard("sports"),
            totalStudents[6]);
        hobbiesPercentages[SPORT_INDEX] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getHeard("music"),
            totalStudents[7]);
        hobbiesPercentages[MUSIC_INDEX] = otherLike;
    }


    public void updateHobbiesLikePercentages()
    {
        int csLike = this.calculateLikePercentage(this.getLike("reading"),
            totalStudents[4]);
        hobbiesPercentages[READ_INDEX + 1] = csLike;
        int engeLike = this.calculateLikePercentage(this.getLike("art"),
            totalStudents[5]);
        hobbiesPercentages[ART_INDEX + 1] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getLike("sports"),
            totalStudents[6]);
        hobbiesPercentages[SPORT_INDEX + 1] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getLike("music"),
            totalStudents[7]);
        hobbiesPercentages[MUSIC_INDEX + 1] = otherLike;
    }


    public void updateStatesHeardPercentages()
    {
        int csLike = this.calculateLikePercentage(this.getHeard("Northeast"),
            totalStudents[8]);
        statesPercentages[NORTH_EAST_INDEX] = csLike;
        int engeLike = this.calculateLikePercentage(this.getHeard("Southeast"),
            totalStudents[9]);
        statesPercentages[SOUTH_EAST_INDEX] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getHeard(
            "United States (other than Southeast or Northwest)"),
            totalStudents[10]);
        statesPercentages[REST_US_INDEX] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getHeard(
            "Outside of United States"), totalStudents[11]);
        statesPercentages[OUTSIDE_US_INDEX] = otherLike;
    }


    public void updateStatesLikePercentages()
    {
        int csLike = this.calculateLikePercentage(this.getLike("Northeast"),
            totalStudents[8]);
        statesPercentages[NORTH_EAST_INDEX + 1] = csLike;
        int engeLike = this.calculateLikePercentage(this.getLike("Southeast"),
            totalStudents[9]);
        statesPercentages[SOUTH_EAST_INDEX + 1] = engeLike;
        int mathLike = this.calculateLikePercentage(this.getLike(
            "United States (other than Southeast or Northwest)"),
            totalStudents[10]);
        statesPercentages[REST_US_INDEX + 1] = mathLike;
        int otherLike = this.calculateLikePercentage(this.getLike(
            "Outside of United States"), totalStudents[11]);
        statesPercentages[OUTSIDE_US_INDEX + 1] = otherLike;
    }


    public int calculateHeardPercentage(int heard, int total)
    {
        if (total == 0)
        {
            heardPercentage = 0;
            return heardPercentage;

        }
        else
        {
            heardPercentage = (int)(((double)(heard) / (double)(total)) * 100);
        }
        return heardPercentage;
    }


    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append(this.getTitle() + ", ");
        builder.append(this.getArtist() + ", ");
        builder.append(this.getDate() + ", ");
        builder.append(this.getGenre());
        return builder.toString();

    }


    public int[] getMajors()
    {
        return majors;
    }


    public int[] getHobbies()
    {
        return hobbies;
    }


    public int[] getStates()
    {
        return states;
    }
}
