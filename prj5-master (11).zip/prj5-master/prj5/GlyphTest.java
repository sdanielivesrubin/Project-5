package prj5;

import student.TestCase;

/**
 * Test for Glyph class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.10
 *
 */
public class GlyphTest extends TestCase {

    Glyph glyph;

    /**
     * Sets up test methods
     */
    public void setUp() {
        glyph = new Glyph();
    }

    /**
     * Test createBar() method
     */
    public void testCreateBar() {
        Exception thrown = null;
        try {
            glyph.createBar("nothing", 50, 50);
        }
        catch (Exception e) {
            thrown = e;
        }
        assertNotNull(thrown);
        assertTrue(thrown instanceof IllegalArgumentException);
        glyph.createBar("top", 10, 10);
        assertEquals(300, glyph.getTopBar().getWidth());
        glyph.createBar("midTop", 10, 10);
        assertEquals(300, glyph.getMidTopBar().getWidth());
        glyph.createBar("midBottom", 10, 10);
        assertEquals(300, glyph.getMidBottomBar().getWidth());
        glyph.createBar("bottom", 10, 10);
        assertEquals(300, glyph.getBottomBar().getWidth());
    }
}
