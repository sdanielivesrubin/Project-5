package prj5;

/**
 * Input Class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.07
 */

public class Input
{

    public static void main(String[] args)

    {
        SurveyReader reader = null;

        String surveyFile;

        String songFile;

        if (args.length >= 2)

        {

            surveyFile = args[0];

            songFile = args[1];

            reader = new SurveyReader(surveyFile, songFile);

        }

        else

        {

            reader = new SurveyReader("MusicSurveyData.csv", "SongList.csv");

        }
        // GUIWindow window = new GUIWindow();
        SongList<Song> output = reader.getSongs();
        output.sortByGenre();
        System.out.println(output.toString());
        output.sortByTitle();
        System.out.println(output.toString());

    }

}
