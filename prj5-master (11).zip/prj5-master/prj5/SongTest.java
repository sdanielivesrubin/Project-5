package prj5;

import student.TestCase;

/**
 * Song Test Class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 11/09/2016
 */
public class SongTest extends TestCase
{

    private Song song;


    public void setUp()
    {
        song = new Song("Banana Pancakes", "Jack Johnson", "Accoustic", "2008");
    }


    public void testGetTitle()
    {
        assertEquals("Banana Pancakes", song.getTitle());
    }


    public void testGetArtist()
    {
        assertEquals("Jack Johnson", song.getArtist());
    }


    public void testGetGenre()
    {
        assertEquals("Accoustic", song.getGenre());
    }


    public void testGetDate()
    {
        assertEquals("2008", song.getDate());
    }


    public void testUpdateHeardMajors()
    {
        song.updateHeardMajors("Computer Science");
        assertEquals(1, song.getMajors()[0]);
        song.updateHeardMajors("Other Engineering");
        assertEquals(1, song.getMajors()[2]);
        song.updateHeardMajors("Math or CMDA");
        assertEquals(1, song.getMajors()[4]);
        song.updateHeardMajors("Other");
        assertEquals(1, song.getMajors()[6]);
    }


    public void testUpdateLikeMajors()
    {
        song.updateLikeMajors("Computer Science");
        assertEquals(1, song.getMajors()[1]);
        song.updateLikeMajors("Other Engineering");
        assertEquals(1, song.getMajors()[3]);
        song.updateLikeMajors("Math or CMDA");
        assertEquals(1, song.getMajors()[5]);
        song.updateLikeMajors("Other");
        assertEquals(1, song.getMajors()[7]);
    }


    public void testUpdateHeardHobbies()
    {
        song.updateHeardHobbies("reading");
        assertEquals(1, song.getHobbies()[0]);
        assertEquals(1, song.getHeard("reading"));
        song.updateHeardHobbies("art");
        assertEquals(1, song.getHobbies()[2]);
        song.updateHeardHobbies("sports");
        assertEquals(1, song.getHobbies()[4]);
        song.updateHeardHobbies("music");
        assertEquals(1, song.getHobbies()[6]);
    }


    public void testUpdateLikeHobbies()
    {
        song.updateLikeHobbies("reading");
        assertEquals(1, song.getHobbies()[1]);
        song.updateLikeHobbies("art");
        assertEquals(1, song.getHobbies()[3]);
        song.updateLikeHobbies("sports");
        assertEquals(1, song.getHobbies()[5]);
        song.updateLikeHobbies("music");
        assertEquals(1, song.getHobbies()[7]);

    }


    public void testUpdateHeardStates()
    {
        song.updateHeardStates("Northeast");
        assertEquals(1, song.getStates()[0]);
        song.updateHeardStates("Southeast");
        assertEquals(1, song.getStates()[2]);
        song.updateHeardStates(
            "United States (other than Southeast or Northwest)");
        assertEquals(1, song.getStates()[4]);
        song.updateHeardStates("Outside of United States");
        assertEquals(1, song.getStates()[6]);
    }


    public void testUpdateLikeStates()
    {
        song.updateLikeStates("Northeast");
        assertEquals(1, song.getStates()[1]);
        assertEquals(1, song.getLike("Northeast"));
        song.updateLikeStates("Southeast");
        assertEquals(1, song.getStates()[3]);
        song.updateLikeStates(
            "United States (other than Southeast or Northwest)");
        assertEquals(1, song.getStates()[5]);
        song.updateLikeStates("Outside of United States");
        assertEquals(1, song.getStates()[7]);
    }


    public void testGetLike()
    {

        assertEquals(0, song.getLike("Computer Science"));
        assertEquals(0, song.getLike("Other Engineering"));
        assertEquals(0, song.getLike("Math or CMDA"));
        assertEquals(0, song.getLike("Other"));
        assertEquals(0, song.getLike("read"));
        assertEquals(0, song.getLike("art"));
        assertEquals(0, song.getLike("sports"));
        assertEquals(0, song.getLike("music"));
        assertEquals(0, song.getLike("Northeast"));
        assertEquals(0, song.getLike("Southeast"));
        assertEquals(0, song.getLike(
            "United States (other than Southeast or Northwest)"));
        assertEquals(0, song.getLike("Outside of United States"));
    }


    public void testGetHeard()
    {
        assertEquals(0, song.getHeard("Computer Science"));
        assertEquals(0, song.getHeard("Other Engineering"));
        assertEquals(0, song.getHeard("Math or CMDA"));
        assertEquals(0, song.getHeard("Other"));
        assertEquals(0, song.getHeard("read"));
        assertEquals(0, song.getHeard("art"));
        assertEquals(0, song.getHeard("sports"));
        assertEquals(0, song.getHeard("music"));
        assertEquals(0, song.getHeard("Northeast"));
        assertEquals(0, song.getHeard("Southeast"));
        assertEquals(0, song.getHeard(
            "United States (other than Southeast or Northwest)"));
        assertEquals(0, song.getHeard("Outside of United States"));
    }


    public void testCalculateLikePercentage()
    {
        assertEquals(0, song.calculateLikePercentage(1000, 0));
        assertEquals(1000, song.calculateLikePercentage(1000, 100));
        assertEquals(66, song.calculateLikePercentage(2, 3));
        //
    }


    public void testCalculateHeardPercentage()
    {
        assertEquals(0, song.calculateHeardPercentage(1000, 0));
        assertEquals(1000, song.calculateHeardPercentage(1000, 100));
        assertEquals(66, song.calculateHeardPercentage(2, 3));
    }


    public void testToString()
    {
        assertEquals("Banana Pancakes, Jack Johnson, 2008, Accoustic", song
            .toString());
    }

}
