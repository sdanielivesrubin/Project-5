package prj5;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

/**
 * Song List Class
 * 
 * @author Yasmine Belghith (byasmine)
 * @author Daniel Rubin (danielir)
 * @version 2016.11.07
 */

public class SongList<T> extends SinglyLinkedList<T>
{

    /**
     * Constructor
     */

    public SongList()

    {

        super();

    }


    /**
     * creates an array from this SongList sorts the array given the input
     * comparator clears this list adds elements back to this list from the
     * array in specified order
     * 
     * @param comparator
     *            the comparator to be used for comparing elements
     */

    @SuppressWarnings("unchecked")

    public void sort(Comparator<Song> comparator)

    {

        Song[] arrayToSort = (Song[])super.toArray();

        Arrays.sort(arrayToSort, comparator);

        this.clear();

        for (int i = 0; i < arrayToSort.length; i++)

        {

            this.add(i, (T)arrayToSort[i]);

        }

    }


    /**
     * Creates a sorted song list in alphabetical order by Title
     * 
     * @param comparator
     *            Comparator
     */

    public void sortByTitle()

    {

        Comparator<Song> titleComparator = new CompareSongByTitle();

        sort(titleComparator);

        this.toString();

    }


    /**
     * Creates a sorted song list in alphabetical order by Artist
     * 
     * @param comparator
     *            Comparator
     */

    public void sortByArtist()

    {

        Comparator<Song> artistComparator = new CompareSongByArtist();

        sort(artistComparator);

        this.toString();

    }


    /**
     * Creates a sorted song list in alphabetical order by Genre
     * 
     * @param comparator
     *            Comparator
     */

    public void sortByGenre()

    {

        Comparator<Song> genreComparator = new CompareSongByGenre();

        sort(genreComparator);

        this.toString();

    }


    /**
     * Creates a sorted song list in alphabetical order by Date (earliest to
     * latest)
     * 
     * @param comparator
     *            Comparator
     */

    public void sortByDate()

    {

        Comparator<Song> dateComparator = new CompareSongByDate();

        sort(dateComparator);

        this.toString();

    }


    /**
     * Prints the Song List
     */

    public String toString()

    {

        Iterator<T> iter = this.iterator();

        StringBuilder sb = new StringBuilder();

        Song song;

        while (iter.hasNext())

        {

            song = (Song)iter.next();

            sb.append("Song Title: " + song.getTitle() + "\n");

            sb.append("Song Artist: " + song.getArtist() + "\n");

            sb.append("Song Genre: " + song.getGenre() + "\n");

            sb.append("Song Year: " + song.getDate() + "\n");

            sb.append("Heard \n");

            sb.append("reading:" + song.hobbiesPercentages[0] + " art:"
                + song.hobbiesPercentages[2]

                + " sports:" + song.hobbiesPercentages[4] + " music:"
                + song.hobbiesPercentages[6] + "\n");

            sb.append("Likes \n");

            sb.append("reading:" + song.hobbiesPercentages[1] + " art:"
                + song.hobbiesPercentages[3]

                + " sports:" + song.hobbiesPercentages[5] + " music:"
                + song.hobbiesPercentages[7]);

            sb.append("\n");

        }

        return sb.toString();

    }


    /**
     * Determines whether one song list is equal to another song list
     */

    public boolean equals(Object other)

    {

        return false;

    }

}
