package prj5;

import java.awt.Color;
import CS2114.Shape;

/**
 * Glyph class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.07
 */
public class Glyph extends Shape
{

    private Shape            topBar;

    private Shape            midTopBar;

    private Shape            midBottomBar;

    private Shape            bottomBar;

    private final static int HEIGHT         = 5;

    private final static int VERTICAL_WIDTH = 3;

    private final static int WIDTH          = 15;

    private final static int MARGIN         = 3;


    /**
     * constructs a new glyph shape
     */
    public Glyph()
    {
        super(0, 0);
        topBar = new Shape(0, 0, 0, HEIGHT);
        topBar.setBackgroundColor(Color.PINK);
        midTopBar = new Shape(0, 0, 0, HEIGHT);
        midTopBar.setBackgroundColor(Color.BLUE);
        midBottomBar = new Shape(0, 0, 0, HEIGHT);
        midBottomBar.setBackgroundColor(Color.YELLOW);
        bottomBar = new Shape(0, 0, 0, HEIGHT);
        bottomBar.setBackgroundColor(Color.GREEN);
        Shape vertical = new Shape(0, 0, VERTICAL_WIDTH, HEIGHT + MARGIN);
        vertical.setBackgroundColor(Color.BLACK);
    }


    /**
     * getter method for the topBar
     * 
     * @return return the topBar
     */
    public Shape getTopBar()
    {
        return topBar;
    }


    /**
     * return the Mid top bar
     * 
     * @return returns the midtopbar object
     */
    public Shape getMidTopBar()
    {
        return midTopBar;
    }


    /**
     * getter method midbottom bar
     * 
     * @return the midbottom bar object
     */
    public Shape getMidBottomBar()
    {
        return midBottomBar;
    }


    /**
     * getter mehtod for the bottom bar object
     * 
     * @return returns the bottombar
     */
    public Shape getBottomBar()
    {
        return bottomBar;
    }


    /**
     * createbar method will move the glyphs to the correct position
     * 
     * @param shapePosition
     *            the location we would like to move to
     * @param like
     *            the number of likes
     * @param heard
     *            the number of heards
     */
    public void createBar(String shapePosition, int like, int heard)
    {
        if (shapePosition.equals("top"))
        {
            this.topBar = new Shape(0, 0, this.calculateWidth(like, heard),
                HEIGHT);
        }
        else if (shapePosition.equals("midTop"))
        {
            this.midTopBar = new Shape(0, 0, this.calculateWidth(like, heard),
                HEIGHT);
        }
        else if (shapePosition.equals("midBottom"))
        {
            this.midBottomBar = new Shape(0, 0, this.calculateWidth(like,
                heard), HEIGHT);
        }
        else if (shapePosition.equals("bottom"))
        {
            this.bottomBar = new Shape(0, 0, this.calculateWidth(like, heard),
                HEIGHT);
        }
        else
        {
            throw new IllegalArgumentException(
                "Cannot find the right position");
        }
    }


    /**
     * calculate method for each glyph object
     * 
     * @param like
     *            number of likes
     * @param heard
     *            number of people who heard
     * @return the width of this glyph
     */
    private int calculateWidth(int like, int heard)
    {
        return (like + heard) * WIDTH;
    }
}
