package prj5;

import java.util.Comparator;
import student.TestCase;

/**
 * @author Daniel Rubin
 * @author Danielir
 * @version 11-3-16 Lab 11 Sorted Linked List Test
 */
public class SongListTest extends TestCase
{

    private Comparator<Song> artistComparator;
    private Comparator<Song> dateComparator;
    private Comparator<Song> titleComparator;
    private Comparator<Song> genreComparator;
    private SongList<Song>   songList;
    private Song             song1;
    private Song             song2;
    private Song             song3;
    private Song             song4;


    /**
     * Test setup makes two types of comparators
     */
    public void setUp()
    {

        artistComparator = new CompareSongByArtist();
        dateComparator = new CompareSongByDate();
        titleComparator = new CompareSongByTitle();
        genreComparator = new CompareSongByGenre();

        songList = new SongList<Song>();

        song1 = new Song("AA", "AA", "AA", "2001");
        song2 = new Song("BB", "BB", "BB", "2002");
        song3 = new Song("CC", "CC", "CC", "2003");
        song4 = new Song("DD", "DD", "DD", "2004");
        
        songList.add(song2);
        songList.add(song3);
        songList.add(song1);
        songList.add(song4);

    }


    /**
     * Test sort by artist
     */
    public void testSortByArtist()
    {
        songList.sort(artistComparator);
        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

        setUp();
        songList.sortByArtist();

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

    }


    /**
     * Test sort by date
     */
    public void testSortByDate()
    {
        songList.sort(dateComparator);

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

        setUp();
        songList.sortByDate();

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

    }


    /**
     * Test sort by title
     */
    public void testSortByTitle()
    {
        songList.sort(titleComparator);

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

        setUp();
        songList.sortByTitle();

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

    }


    /**
     * Test sort by genre
     */
    public void testSortByGenre()
    {
        songList.sort(genreComparator);

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

        setUp();
        songList.sortByGenre();

        assertEquals(song1, songList.get(0));
        assertEquals(song2, songList.get(1));
        assertEquals(song3, songList.get(2));
        assertEquals(song4, songList.get(3));

    }


    /**
     * Test toString
     */
    public void testToString()
    {
        songList.sort(artistComparator);

        assertEquals(551, songList.toString());
    }


    /**
     * Test equals
     */
    public void testEquals()
    {
        SongList<Song> songList2 = new SongList<Song>();
        songList2.add(song2);
        songList2.add(song3);
        songList2.add(song1);
        songList2.add(song4);

        SongList<Song> songList3 = null;

        assertFalse(songList.equals(songList3)); // not null 1

        assertTrue(songList.equals(songList)); // equals itself 2

        assertFalse(songList.equals("songList")); // does not equal a different
                                                  // object 3

        assertTrue(songList.equals(songList2)); // equals another same 4

        songList2 = new SongList<Song>();
        songList2.add(song3);
        songList2.add(song2);
        songList2.add(song1);
        songList2.add(song4);

        assertFalse(songList2.equals(songList));

        songList2.add(song2);

        assertFalse(songList2.equals(songList));

    }

}
