package prj5;

/**
 * Enumerator for Hobby, State, Major
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.13
 */
public enum EnumRepresent
{
    HOBBY, STATE, MAJOR, OTHER;
}
