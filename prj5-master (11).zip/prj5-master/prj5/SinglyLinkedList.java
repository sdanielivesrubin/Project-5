package prj5;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * SinglyLinkedList class
 * 
 * @author Yasmine Belghith (byasmine)
 * @version 2016.11.07
 */
public class SinglyLinkedList<T> implements LList<T>, Iterable<T> // extends
                                                                  // Comparable<?
// super T>>
{

    private int     numberOfEntries;
    private Node<T> firstNode;


    /**
     * instantiates firstNode and numberOfEntries for a new LinkedList
     */
    public SinglyLinkedList()
    {
        firstNode = null;
        numberOfEntries = 0;
    }


    /**
     * returns the number of entries in this Linked List
     * 
     * @return the number of entries of the list
     */
    public int size()
    {
        return numberOfEntries;

    }


    /**
     * adds a new Node to the Linked list at a specified index with data of
     * newEntry. Should throw exceptions if the data is null or if our index is
     * out of bounds
     * 
     * @throws IllegalArgumentException
     *             if the object we are trying to add is a null object
     * @throws IndexOutOfBoundsException
     *             if the index we are trying to add at is outside of the bounds
     */
    public void add(int index, T newEntry)
    {
        if (newEntry == null) // check if the newEntry object is null
        {
            throw new IllegalArgumentException("Object is null");
        }

        if ((index < 0) || (index > size())) // check if the index is out of
                                             // bounds
        {
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }

        Node<T> current = firstNode;

        if (isEmpty()) // empty List case
        {
            firstNode = new Node<T>(newEntry);
        }

        else // all other cases
        {
            int currentIndex = 0;
            while (current != null)
            {
                if ((currentIndex + 1) == index)
                {
                    Node<T> nextNext = current.next;
                    Node<T> newNode = new Node<T>(newEntry);
                    current.setNext(newNode);
                    newNode.setNext(nextNext);

                }
                current = current.getNext();
                currentIndex++;
            }
        }
        numberOfEntries++;
    }


    /**
     * add a new Node to the linked list at the end of the list
     * 
     * @throws IllegalArgumentException
     *             if the object we are trying to add is a null object
     */
    public void add(T newEntry)
    {
        if (newEntry == null) // check if the newEntry object is null
        {
            throw new IllegalArgumentException("Object is null");
        }

        Node<T> current = firstNode;

        // empty stack case
        if (isEmpty())
        {
            firstNode = new Node<T>(newEntry);
        }

        // other cases
        else
        {
            while (current.next != null)
            {
                current = current.next;
            }
            current.setNext(new Node<T>(newEntry));
        }
        numberOfEntries++;
    }


    /**
     * checks if our list is empty
     * 
     * @return true if empty, false otherwise
     */
    public boolean isEmpty()
    {
        return numberOfEntries == 0;
    }


    /**
     * remove an entry from the end of the list
     * 
     * @return true if our T entry has been removed from the list, or false if
     *         our list is empty or the object does not exist
     */
    public boolean remove(T entry)
    {
        Node<T> current = firstNode;

        // account for matching firstNode
        if ((null != firstNode) && (entry.equals(current.data)))
        {
            firstNode = firstNode.next;
            numberOfEntries--;
            return true;
        }

        // account for 2+ numberOfEntries
        while (size() >= 2 && (current.next != null))
        {
            if ((entry.equals(current.next.data)))
            {
                if (current.next.next != null)
                {
                    current.setNext(current.next.next);
                }
                numberOfEntries--;
                return true;
            }
            current = current.next;
        }

        // this accounts for the isEmpty case or the object does not exist
        return false;
    }


    /**
     * removes an element from the list at a specific index
     * 
     * @throws IndexOutOfBoundsException
     *             if our index is outside of the bounds of the list
     * @return true if our T entry has been removed from the list, or false if
     *         our list is empty or the object does not exist
     */
    public boolean remove(int index)
    {
        // if the index is invalid
        if (index < 0 || firstNode == null)
        {
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }
        else
        {

            Node<T> current = firstNode;
            int currentIndex = 0;

            // account for 1 numberOfEntries
            if ((index == 0))
            {
                firstNode = firstNode.next;
                numberOfEntries--;
                return true;
            }

            // account for 2+ numberOfEntries
            while (current.next != null)
            {
                if ((currentIndex + 1) == index)
                {
                    Node<T> newNext = current.next.next;
                    current.setNext(newNext);
                    numberOfEntries--;
                    return true;
                }
                current = current.next;
                currentIndex++;
            }

            // if the element was never found, this also handles empty case
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }
    }


    /**
     * returns an element in the list at a specified index
     * 
     * @throws IndexOutOfBoundsException
     *             is thrown when the specified index is greater than the number
     *             of entries in our linkedlist
     * @return The data stored in the node located at parameter int index
     */
    public T get(int index)
    {
        Node<T> current = firstNode;
        int currentIndex = 0;
        T data = null;
        while (current != null)
        {
            if (currentIndex == index)
            {
                data = current.data;
            }
            currentIndex++;
            current = current.next;
        }

        // check if the data was null...
        if (data == null)
        {
            // ... if so throw an exception
            throw new IndexOutOfBoundsException(
                "Index exceeds the numberOfEntries.");
        }
        return data;
    }


    /**
     * testing if the list contains a certain object
     * 
     * @return true if we found the object in the list, or false otherwise
     */
    public boolean contains(T entry)
    {
        Node<T> current = firstNode;
        while (current != null)
        {
            if (entry.equals(current.data))
            {
                return true;
            }
            current = current.next;
        }

        return false;
    }


    /**
     * clears the list
     */
    public void clear()
    {

        firstNode.setNext(null);
        firstNode = null;
        numberOfEntries = 0;

    }


    /**
     * searches for an entry and returns the last index where it occurred if we
     * did find it
     * 
     * @return the last index of the where the parameter T entry has occurred,
     *         or -1 if we did not find it
     */
    public int lastIndexOf(T entry)
    {
        int lastIndex = -1;
        Node<T> current = firstNode;
        int currentIndex = 0;
        while (current != null)
        {
            if (entry.equals(current.getData()))
            {
                lastIndex = currentIndex;
            }
            currentIndex++;
            current = current.next;

        }
        return lastIndex;
    }


    /**
     * Turns the contents of our Linked List into a String
     */
    public String toString()
    {
        String result = "{";

        Node<T> current = firstNode;
        while (current != null)
        {
            result += "" + current.getData();
            current = current.next;
            if (current != null)
            {
                result += ", ";
            }
        }
        result += "}";
        return result;
    }


    /**
     * turns the contents of this Linked list into an array
     * 
     * @return
     */
    public Song[] toArray()
    {
        Song[] arr = new Song[numberOfEntries];
        for (int i = 0; i < numberOfEntries; i++)
        {
            arr[i] = (Song)this.get(i);
        }
        return arr;
    }


    /**
     * Private Node class
     * 
     * @author Yasmine Belghith (byasmine)
     * @version 2016.11.07
     * @param <E>
     *            the generic type passed in
     */
    private class Node<E>
    {
        protected Node<E> next;
        private E         data;


        /**
         * Creates a new Node object that takes in a parameter with Generic type
         * E. Instantiates the private data field to be equals to this parameter
         * 
         * @param e
         *            The generic data that will go inside the private data
         *            field of the Node
         */
        public Node(E e)
        {
            data = e;
        }


        /**
         * Returns the protected 'next' field of this Node. Should be a Node
         * object.
         * 
         * @return the Node object that is stored in the protected 'next' field
         *         of this Node
         */
        public Node<E> getNext()
        {
            return next;
        }


        /**
         * Returns the private 'data' field of this Node. Should be Generic
         * type.
         * 
         * @return the generic data that is stored in the 'data' field of this
         *         Node
         */
        public E getData()
        {
            return data;
        }


        /**
         * sets the protected 'next' field to be equal to a Node object
         * 
         * @param node
         *            the node we are setting 'next' to be equal to
         */
        public void setNext(Node<E> node)
        {
            next = node;
        }
    }


    /**
     * makes a new SinglyLinkedListIteator object
     * 
     * @return
     */
    public SinglyLinkedListIterator iterator()
    {
        return new SinglyLinkedListIterator();
    }


    /**
     * SinglyLinkedListIterator will iterate through the entries in this linked
     * list. We will use this private class later on to add glyphs to the Window
     * GUI
     */
    private class SinglyLinkedListIterator implements Iterator<T>
    {

        private int     nextPosition;
        private Node<T> currentSong;


        /**
         * Instantiates nextPosition to be equal to 0 and should set the
         * currentSong to be equal to firstNode
         */
        public SinglyLinkedListIterator()
        {
            nextPosition = 0;
            currentSong = firstNode;
        }


        /**
         * Implements the song list iterator to iterate over songs hasNext
         * 
         * @return True if the currentSong's next field is not equal to null, or
         *         in other words if it has a next song. Return false at the end
         *         of the list
         */
        public boolean hasNext()
        {
            return currentSong != null;
        }


        /**
         * Implements the song list iterator to iterate over songs next
         * 
         * @throws NoSuchElementException
         *             if next() is called after the end of our list
         * @return
         */
        public T next()
        {
            if (hasNext())
            {
                Node<T> returnNode = currentSong;
                currentSong = currentSong.next;
                nextPosition++;
                return (T)returnNode.getData();

            }
            else
            {
                throw new NoSuchElementException("Illegal call to next(); "
                    + "iterator is after end of list.");
            }
        }

    }
}
